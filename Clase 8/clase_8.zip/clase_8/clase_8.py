# open, close (w, r, a)

# archivo_abierto = open('texto.txt', 'w')

# # Trabajamos con el archivo
# #  y al finalizar lo debemos cerrar

# archivo_abierto.close()


# with open('texto.txt', 'w') as archivo_abierto:
#     # Trabajamos con el archivo
# # Una vez fuera del with el archivo se cierra solo


# write

# archivo_abierto = open('clase_8/texto.txt', 'w')
# # archivo_abierto = open('clase_8/texto.txt', 'a')

# archivo_abierto.write('Esto es una prueba\n')
# archivo_abierto.write('Soy otra cosa')
# # archivo_abierto.write('Pise el texto')

# archivo_abierto.close()

# read, readline, readlines
# archivo_abierto = open('clase_8/texto.txt', 'r')

# # print(archivo_abierto.read())
# # print('----------------')
# # print(archivo_abierto.read())
# # print('----------------')
# # print(archivo_abierto.readline())
# # print(archivo_abierto.readline())
# # print(archivo_abierto.readline())
# # print(archivo_abierto.readline())
# # print(archivo_abierto.readline())
# # print(archivo_abierto.readlines())

# archivo_abierto.close()

# archivo_abierto = open('clase_8/texto.txt', 'r')

# texto = archivo_abierto.read()

# archivo_abierto.close()

# print(texto)
# print(texto)


# seek


# archivo_abierto = open('clase_8/segundo_texto.txt', 'r')

# print(archivo_abierto.read())
# archivo_abierto.seek(13)
# print('----------------')
# print(archivo_abierto.read())

# print(archivo_abierto.readline())
# archivo_abierto.seek(13)
# print('----------------')
# print(archivo_abierto.readline())

# lineas = archivo_abierto.readlines()

# archivo_abierto.close()

# nuevas_lineas = []
# for linea in lineas:
#     nuevas_lineas.append(linea.capitalize())
    
# print(nuevas_lineas)

# archivo = open('clase_8/segundo_texto.txt', 'w')
# # archivo.write(''.join(nuevas_lineas))
# archivo.write(nuevas_lineas[1])
# archivo.close()

# auto = {
#     'motor': 'v8', 
#     'color': 'Negro',
#     'vidrios': (6, 'blindadas'),
#     'pasajeros': 4,
# }

# with open('clase_8/datos_auto.txt', 'w') as archivo:
#     archivo.write(f'{auto["motor"]}\n')
#     archivo.write(f'{auto["color"]}\n')
#     archivo.write(f'{auto["vidrios"]}\n')
#     archivo.write(f'{auto["pasajeros"]}\n')
#     archivo.write(f'{auto.get("Ricardo", "otro valor")}\n')

# break

# json

# dicc = {
#     'llave1': 'valor1',
#     'llave2': 'valor2',
#     'llave3': 'valor3',
#     'llave4': 'valor4',
#     'auto': auto,
# }

# with open('clase_8/prueba_json.json', 'w') as archivo:
#     archivo.write(dicc)

# import json

# dump
# with open('clase_8/mi_archivo.json', 'w') as archivo_para_guardar:
#     json.dump(dicc, archivo_para_guardar, indent=4)

# load
# with open('clase_8/mi_archivo.json', 'r') as archivo_para_leer:
#     datos = json.load(archivo_para_leer)
#     print(datos)
#     print(type(datos))


# import pandas as pd

# datos = pd.read_csv('clase_8/dataset_viajes_sube.csv')
# print(datos)
# NOT A NUMBER (NaN) => null, None

# print(datos.head())
# print(datos.head(10))

# print(datos.tail())
# print(datos.tail(3))

# print(datos.sample(3))

# print(datos)
# print(datos['TIPO_TRANSPORTE'])
# print(datos['TIPO_TRANSPORTE'].value_counts())